int geraNumero(int limite);
