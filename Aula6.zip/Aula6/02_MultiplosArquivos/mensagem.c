#include <stdio.h>
#include "mensagem.h"

// Mostra a mensagem.
void mensagem() {
    printf("Programa chamando outro programa!\n");
}
