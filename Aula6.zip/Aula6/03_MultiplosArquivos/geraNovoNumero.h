void gerarNovoNumero (char *valorRecebido, int tamanhoVetor, int tipo);
